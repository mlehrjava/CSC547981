#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[]){
    int a[6]; 
    cout << "Enter the numbers in here: "; 
    for (int i = 0; i <= 6; i++)
        cin >> a[i]; 
    cout << endl << "The numbers you entered were: "; 
    for (int count = 0; count <= 6; count++)
        cout << " " << a[count] << endl; 
    system("PAUSE");
    return EXIT_SUCCESS;
}
