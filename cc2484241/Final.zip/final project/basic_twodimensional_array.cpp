#include <cstdlib>
#include <iostream>

using namespace std;

int main(){
    int row = 3, col = 4, total; 
    int number[row][col]; 
    
    for (int num1 = 0; num1 < row; num1++){
        for (int num2 = 0; num2 < col; num2++){
            cout << "Row " << (num1 + 1) << ", "
                 << "Column " << (num2 + 1) << " = "; // Input for 2D array
            cin >> number[num1][num2]; 
        }
        cout << endl;
    }
    
    for (int num1 = 0; num1 < row; num1++){
        for (int num2 = 0; num2 < col; num2++) //Calculate addition of all the numbers. 
            total += number[num1][num2];
    }
    
    cout << "The addition of these number is = " << total << "." << endl; 
    system("PAUSE");
    return EXIT_SUCCESS;
}
